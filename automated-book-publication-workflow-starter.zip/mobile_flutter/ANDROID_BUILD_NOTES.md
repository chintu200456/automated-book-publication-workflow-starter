# Building the APK (Flutter)
1) Install Flutter SDK and Android Studio (with SDK + emulator).
2) From `mobile_flutter/`, run:
   flutter pub get
   flutter config --android-sdk <path-to-android-sdk>   # first time only
   flutter build apk --release
3) The APK will be at: build/app/outputs/flutter-apk/app-release.apk

# Running against backend
- Ensure the FastAPI backend is running on your machine: `uvicorn main:app --reload`
- In Android emulator, use `http://10.0.2.2:8000` as the backend base URL.
- On a physical device connected to the same network, replace with your computer's IP (e.g., http://192.168.1.20:8000).
