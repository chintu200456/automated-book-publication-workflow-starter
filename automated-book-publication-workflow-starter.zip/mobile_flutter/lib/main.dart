import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const BookWorkflowApp());
}

class BookWorkflowApp extends StatelessWidget {
  const BookWorkflowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Automated Book Workflow',
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _urlController = TextEditingController(text: "https://example.com");
  final TextEditingController _backendController = TextEditingController(text: "http://10.0.2.2:8000");
  String _status = "Idle";
  String _generated = "";

  Future<void> _runPipeline() async {
    final base = _backendController.text.trim();
    setState(() { _status = "Ingesting..."; });
    final ing = await http.post(Uri.parse("$base/ingest/url"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"urls": [_urlController.text], "max_chars": 5000})
    );
    if (ing.statusCode != 200) {
      setState(() { _status = "Ingest failed: ${ing.statusCode}"; });
      return;
    }

    setState(() { _status = "Generating..."; });
    final gen = await http.post(Uri.parse("$base/generate"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "outline": ["Overview", "Body", "Conclusion"],
        "notes": "Triggered from mobile app"
      })
    );
    if (gen.statusCode != 200) {
      setState(() { _status = "Generate failed: ${gen.statusCode}"; });
      return;
    }
    final genJson = jsonDecode(gen.body);
    final docId = genJson["document_id"];

    setState(() { _status = "Reviewing..."; });
    await http.post(Uri.parse("$base/review"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"document_id": docId, "approve": true, "feedback": "Auto-approved from app"})
    );

    setState(() { _status = "Publishing..."; });
    final pub = await http.post(Uri.parse("$base/publish/$docId?format=markdown"));
    if (pub.statusCode == 200) {
      final pubJson = jsonDecode(pub.body);
      setState(() { _generated = pubJson["content"] ?? ""; _status = "Done"; });
    } else {
      setState(() { _status = "Publish failed: ${pub.statusCode}"; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Automated Book Workflow")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _backendController,
              decoration: const InputDecoration(labelText: "Backend URL (e.g., http://10.0.2.2:8000)"),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(labelText: "Source URL to ingest"),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _runPipeline,
              child: const Text("Run Pipeline"),
            ),
            const SizedBox(height: 12),
            Text("Status: $_status"),
            const Divider(),
            const Text("Generated Output:"),
            Expanded(
              child: SingleChildScrollView(
                child: Text(_generated),
              ),
            )
          ],
        ),
      ),
    );
  }
}
