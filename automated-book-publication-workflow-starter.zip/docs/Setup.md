# Setup & Run

## Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Open docs at: http://localhost:8000/docs

## Orchestrator
```bash
cd orchestrator
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python orchestrator.py
```

## Mobile (Flutter)
See `mobile_flutter/ANDROID_BUILD_NOTES.md` for APK build steps.
