# Architecture Overview

- **Backend (FastAPI):** Exposes endpoints for ingest, generate, review, and publish. Stores state in memory for demo.
- **Orchestrator (Python):** Calls backend in a pipeline with retries, representing agentic automation.
- **Mobile (Flutter):** Simple UI to trigger pipeline and display generated output.

Recommended production upgrades:
- Replace in-memory DB with PostgreSQL.
- Add authentication (JWT), roles (Author/Reviewer/Publisher).
- Use a task queue (Celery / RQ) for long-running jobs.
- Integrate a real LLM provider.
- Add rate-limiting & telemetry.
