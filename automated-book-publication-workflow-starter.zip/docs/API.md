# API Reference (Backend)

## `GET /health`
- Returns API status and UTC time.

## `POST /ingest/url`
Body:
```json
{ "urls": ["https://example.com"], "max_chars": 20000 }
```
Response:
```json
{ "document_id": "uuid", "sections": 1 }
```

## `POST /ingest/file`
Form-Data:
- file: UploadFile
- max_chars: int

## `POST /generate`
Body:
```json
{ "outline": ["Intro","Body","Conclusion"], "notes": "text" }
```
Response:
- `document_id`, `content` (markdown)

## `GET /document/{document_id}`
Returns full in-memory document.

## `POST /review`
Body:
```json
{ "document_id": "uuid", "feedback": "text", "approve": true }
```

## `POST /publish/{document_id}?format=markdown|json`
Returns published content.
