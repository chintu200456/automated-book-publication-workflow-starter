# Software Requirements Specification (SRS) — Automated Book Publication Workflow

## 1. Purpose
Automate the ingestion, generation, review, and publication of long-form book content with human-in-the-loop controls.

## 2. Functional Requirements
- Ingest content from URLs and files.
- Generate structured chapters from outlines and notes.
- Queue human review actions (approve/request changes with feedback).
- Publish in Markdown and JSON formats.
- Mobile client can trigger and monitor pipeline stages.

## 3. Non-Functional Requirements
- Reliability: API health check, basic retry logic in orchestrator.
- Usability: Simple Flutter UI to trigger pipeline.
- Performance: Handle inputs up to 20k characters per source (configurable).
- Security: CORS allowed for demo; add auth (JWT) for production.
- Portability: Dockerizable backend; Flutter for Android app.

## 4. Tech Stack
- Backend: FastAPI (Python)
- Orchestrator: Python worker
- Mobile: Flutter
- Storage: In-memory (demo); replace with PostgreSQL in production.

## 5. Constraints
- Demo project; no proprietary LLM calls included.
- Internet scraping subject to robots.txt and legal limits.
