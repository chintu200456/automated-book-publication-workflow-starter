from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import requests
from bs4 import BeautifulSoup
import uuid, datetime

app = FastAPI(title="Automated Book Publication Workflow API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class IngestURLRequest(BaseModel):
    urls: List[str]
    max_chars: int = 20000

class GenerateRequest(BaseModel):
    outline: Optional[List[str]] = None
    prompt: str = "Write a coherent chapter based on provided notes."
    notes: Optional[str] = None

class ReviewAction(BaseModel):
    document_id: str
    feedback: Optional[str] = None
    approve: bool = False

DB: Dict[str, Dict[str, Any]] = {}

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.datetime.utcnow().isoformat()}

@app.post("/ingest/url")
def ingest_url(req: IngestURLRequest):
    contents = []
    for url in req.urls:
        try:
            r = requests.get(url, timeout=10)
            soup = BeautifulSoup(r.text, "html.parser")
            text = " ".join([t.get_text(" ", strip=True) for t in soup.find_all(["p","article","div","span"])])
            text = text[:req.max_chars]
            contents.append({"source": url, "content": text})
        except Exception as e:
            contents.append({"source": url, "error": str(e)})
    doc_id = str(uuid.uuid4())
    DB[doc_id] = {"status": "ingested", "sections": contents, "history": []}
    return {"document_id": doc_id, "sections": len(contents)}

@app.post("/ingest/file")
async def ingest_file(file: UploadFile = File(...), max_chars: int = Form(20000)):
    raw = await file.read()
    text = raw.decode(errors="ignore")[:max_chars]
    doc_id = str(uuid.uuid4())
    DB[doc_id] = {"status": "ingested", "sections": [{"source": file.filename, "content": text}], "history": []}
    return {"document_id": doc_id, "sections": 1}

@app.post("/generate")
def generate(req: GenerateRequest):
    # Placeholder text generation. Replace with your LLM of choice.
    chapter = []
    outline = req.outline or ["Introduction", "Body", "Conclusion"]
    notes = req.notes or "No notes provided."
    for i, h in enumerate(outline, start=1):
        chapter.append(f"# {h}\n\nThis section elaborates on '{h}'. Notes: {notes}\n")
    content = "\n".join(chapter)
    doc_id = str(uuid.uuid4())
    DB[doc_id] = {"status": "generated", "sections": [{"source": "generator", "content": content}], "history": []}
    return {"document_id": doc_id, "content": content}

@app.get("/document/{document_id}")
def get_document(document_id: str):
    return DB.get(document_id, {"error": "not_found"})

@app.post("/review")
def review(action: ReviewAction):
    doc = DB.get(action.document_id)
    if not doc:
        return {"error": "not_found"}
    if action.approve:
        doc["status"] = "approved"
        doc["history"].append({"event": "approved", "feedback": action.feedback})
    else:
        doc["status"] = "changes_requested"
        doc["history"].append({"event": "changes_requested", "feedback": action.feedback})
    return {"document_id": action.document_id, "status": doc["status"]}

@app.post("/publish/{document_id}")
def publish(document_id: str, format: str = "markdown"):
    doc = DB.get(document_id)
    if not doc:
        return {"error": "not_found"}
    if format == "markdown":
        content = "\n\n".join([s["content"] for s in doc.get("sections", [])])
        return {"document_id": document_id, "format": "markdown", "content": content}
    elif format == "json":
        return {"document_id": document_id, "format": "json", "content": doc}
    else:
        return {"error": "unsupported_format"}
