# Automated Book Publication Workflow (Starter Kit)

This is a runnable starter kit for your Project 11. It includes:
- FastAPI backend
- Python orchestrator
- Flutter mobile app (build an APK from this)
- Docs (requirements, API, setup, architecture)

## Quickstart
1. Start the backend (FastAPI) — see `docs/Setup.md`.
2. Run the orchestrator or the Flutter app to drive the workflow.
3. Build the APK from `mobile_flutter/` using `flutter build apk --release`.

## Notes
- The generator is a placeholder to keep this repo offline-friendly. Swap with your preferred LLM provider.
- In the Android emulator, use `http://10.0.2.2:8000` as the backend URL.
